
public class wallet {

	private static int money = 100;
	public wallet() {};
	
	
	// this method can get the vaule of wallet
	public static  int getMoney() {
		return money;
	}
	// this can change value of wallet
	public static void setmoney(int betmoney) {
		money = money-betmoney;
	}
	

}
