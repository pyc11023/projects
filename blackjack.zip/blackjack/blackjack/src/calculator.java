import java.util.ArrayList;

public class calculator {
	
	
	
	public static ArrayList<String> onhands = new ArrayList<String>();
	private int dealcountface=0;
	private int pcountface=0;
	private int dealremainder=0;
	private int premainder=0;

	/*this method dicide who is the winner of one round by the arrraylist which stored the cards of dealer's and player's(after nor repalcement) hands*/
	
	public boolean winorloss(){
		
		
		for (int i = 0; i<onhands.size();i++) {
			String a ="";
			a = onhands.get(i).substring(1);
			onhands.set(i, a);
		}
		
		judge();
		
		if (dealcountface>pcountface) {
			return false;
		}
		
		else if (pcountface>dealcountface) {
			return true;
		}
		else {
			if(premainder> dealremainder) {
				return true;
			}
		}
		
		
		
		
		return false;	
	}
	
	
	
	private void judge() {
		ArrayList<Integer> playtemp = new ArrayList<Integer>();
		ArrayList<Integer> dealertemp = new ArrayList<Integer>();

		
		
		for (int i = 0;i<3;i++) {
			int temp1;
			int temp2;
			
			temp1 = Integer.parseInt(onhands.get(i));
			temp2 = Integer.parseInt(onhands.get(i+3));
			playtemp.add(temp2);
			dealertemp.add(temp1);
			
		}
		
		for (int i = 0;i<3;i++) {      //check player hands ? faces
			if ( playtemp.get(i)>10) {
				pcountface++;
				playtemp.set(i, 0);
			}
			
		}
		for (int i = 0;i<3;i++) { // check dealer hands ? faces
			if ( dealertemp.get(i)>10) {
				dealcountface++;
				dealertemp.set(i, 0);
			}
			
		}
		for (int i = 0;i<3;i++) { // check dealer and player remainder
			dealremainder += dealertemp.get(i);
			
			premainder += playtemp.get(i);
		}
		dealremainder = dealremainder%10;
		premainder = premainder%10;
		
		/*System.out.println("d face  " + dealcountface);
		System.out.println("p face  "  + pcountface);
		System.out.println("dealremainder  "+ dealremainder);
		
		System.out.println("premainder"+ premainder);*/
		
		
		
		
		
		
		
		
		onhands.removeAll(onhands);
		
		
	}
	

}
