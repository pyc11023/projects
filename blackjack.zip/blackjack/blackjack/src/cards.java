import java.util.ArrayList;
import java.util.Random;

public class cards { 
	ArrayList<String> cardref = new ArrayList<String>();
	static ArrayList<String> top8cards = new ArrayList<String>();
	static ArrayList<String> onhands = new ArrayList<String>();
 
    // this Initialize a full set of 52 cards and then provide which are the top 8cards by the public arraylist top8hands
    public void Initializecards() {

        Random random = new Random();
        
        // Populate the card reference list
        for (int i = 1; i <= 4; i++) {
            for (int j = 1; j <= 13; j++) {
                String card = i + "" + j;
                cardref.add(card);
            }
        }
        
        // Generate 8 random cards
        int numCards = 52;
        for (int i = 0; i < 8; i++) {
            int randomIndex = random.nextInt(numCards);
            top8cards.add(cardref.get(randomIndex));
            cardref.remove(randomIndex);
            numCards--;
        }
        
        // Print the top 8 cards
        for (String card : top8cards) {
            //System.out.println("top 8 "+card);
        } 
        
        
        
        
        
        
    }
}