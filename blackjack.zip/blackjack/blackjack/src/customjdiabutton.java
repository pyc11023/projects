import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

public class customjdiabutton {

	
	
	// this method will do what if player win a round to the gui, like pop up message window with winning message, disable the button for next round, return money and reward to the wallet
	  public void  showDialogwin(JFrame parentFrame) {
	        JDialog dialog = new JDialog(parentFrame, "Custom Dialog", true);
	        dialog.setSize(300, 150);
	        dialog.setLayout(new GridBagLayout());
	        JLabel winmess = new JLabel("Congratulations! You win this round!");
	        GridBagConstraints c = new GridBagConstraints();

	        JButton okButton = new JButton("OK");
	        
	        okButton.addActionListener(new ActionListener() {
	            public void actionPerformed(ActionEvent e) {
	            	
	                
	                dialog.dispose();
	            }});
	        c.gridy=0;
	        c.gridx = 0;
			c.insets = new Insets(0, 0, 20,0);
	        dialog.getContentPane().add(winmess,c);
	        c.gridy = 1;
	        c.gridx = 0;
	        c.insets = new Insets(0, 0, 0,0);
	        dialog.getContentPane().add(okButton,c);
	        dialog.setVisible(true);
	        }

	// this method will do what if player loss a round to the gui, like pop up message window with lossing message, disable the button for next round, deduct money from the wallet
	  public void  showDialogloss(JFrame parentFrame) {
	        JDialog dialog = new JDialog(parentFrame, "Custom Dialog", true);
	        dialog.setSize(300, 150);
	        dialog.setLayout(new GridBagLayout());
	        JLabel winmess = new JLabel("Sorry! The dealer wins this round!");
	        GridBagConstraints c = new GridBagConstraints();

	        JButton okButton = new JButton("OK");
	        
	        okButton.addActionListener(new ActionListener() {
	            public void actionPerformed(ActionEvent e) {
	            	
	                
	                dialog.dispose();
	            }});
	        c.gridy=0;
	        c.gridx = 0;
			c.insets = new Insets(0, 0, 20,0);
	        dialog.getContentPane().add(winmess,c);
	        c.gridy = 1;
	        c.gridx = 0;
	        c.insets = new Insets(0, 0, 0,0);
	        dialog.getContentPane().add(okButton,c);
	        dialog.setVisible(true);
	        }
	// this method will do what if player loss all money to the gui, like pop up message window with lossing message, disable all button and function of the game
	  public void  showDialoglossall(JFrame parentFrame) {
	        JDialog dialog = new JDialog(parentFrame, "Custom Dialog", true);
	        dialog.setSize(500, 150);
	        dialog.setLayout(new GridBagLayout());
	        JLabel winmess = new JLabel("Gameover! \n"
	        		+ "You have no more money! \n"
	        		+"Please start a new game!");
	        GridBagConstraints c = new GridBagConstraints();

	        JButton okButton = new JButton("OK");
	        
	        okButton.addActionListener(new ActionListener() {
	            public void actionPerformed(ActionEvent e) {
	            	
	                
	                dialog.dispose();
	            }});
	        c.gridy=0;
	        c.gridx = 0;
			c.insets = new Insets(0, 0, 20,0);
	        dialog.getContentPane().add(winmess,c);
	        c.gridy = 1;
	        c.gridx = 0;
	        c.insets = new Insets(0, 0, 0,0);
	        dialog.getContentPane().add(okButton,c);
	        dialog.setVisible(true);
	        }


}
