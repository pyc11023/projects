import javax.swing.*;
import javax.swing.text.TabStop;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class GUI {
	GridBagConstraints c = new GridBagConstraints(); 
	GridBagConstraints f = new GridBagConstraints(); 
	GridBagConstraints b = new GridBagConstraints(); 
	JPanel panel = new JPanel();  
	JPanel panel2 = new JPanel(); 
	JPanel panel3 =  new JPanel();
	
    ImageIcon imageIcon = new ImageIcon("src//images//card_back.gif");
    Image image = imageIcon.getImage().getScaledInstance(150, 230, Image.SCALE_SMOOTH);
    JLabel label = new JLabel(new ImageIcon(image));
    JLabel label2 = new JLabel(new ImageIcon(image));
    JLabel label3 = new JLabel(new ImageIcon(image));
    JLabel label4 = new JLabel(new ImageIcon(image));
    JLabel label5 = new JLabel(new ImageIcon(image));
    JLabel label6 = new JLabel(new ImageIcon(image));
	JButton result = new JButton("Result");
	JButton start = new JButton("Start");
	JTextField field = new JTextField(15);
	   public int bet;
    int a = 0;
	JLabel currentbet = new JLabel("Your currentb bet is:$" + bet);
	JLabel amount = new JLabel("Amount of money you have:$" + wallet.getMoney());
	JFrame frame = new JFrame();  
	   JButton button1 = new JButton("Repalce Card 1"); 
	   JButton button2 = new JButton("Repalce Card 2"); 
	   JButton button3 = new JButton("Repalce Card 3"); 
	   int replacecount = 0;
	
	// this method is setting up the frame
	public void go() {
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setLayout(new GridBagLayout()); 
		frame.setSize(2000, 2000);
		frame.setBackground(Color.GREEN);
		cardtablesetup();
		
		JMenuBar menuBar = new JMenuBar();  
		JMenu menu = new JMenu("Control");
		JMenuItem menuItem = new JMenuItem("Exit");
		menuItem.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });
		menu.add(menuItem);
        menuBar.add(menu);
        frame.setJMenuBar(menuBar);

		
		f.gridy=0;
		f.gridx=0;
        frame.add(panel,f);
        
		f.gridy=1;
		f.gridx=0;
		frame.add(panel3,f);
		
        frame.pack();
        frame.setVisible(true);
        
        
	
	
	

}   //this method is setting up the panels
	public void cardtablesetup() {
		panel.setLayout(new GridBagLayout()); 
		panel.setBackground(Color.GREEN);
		c.gridx = 0;
		c.gridy = 0;
		c.gridwidth = 1; // default value  
		c.gridheight = 1; // default value  
		c.weightx = 0.0; // default value  
		c.weighty = 0.0; // default value
		c.anchor = GridBagConstraints.CENTER; // default value
		c.fill = GridBagConstraints.NONE;	
		c.insets = new Insets(30, 30, 30,30); // default value  
		c.ipadx = 0; // default value
		c.ipady =  0; // default value

		
		c.insets = new Insets(30, 30, 30,30);
        c.gridx = 0;
        panel.add(label, c);
        
        
		c.insets = new Insets(30, 5, 30,5); // default value  
        c.gridx = 1;
        
        panel.add(label2, c);
        
		c.insets = new Insets(30, 30, 30,30); // default value  
        c.gridx = 2;
        
        panel.add(label3, c);
        
        c.insets = new Insets(0, 30, 0,30);
        c.gridy = 1;
        c.gridx = 0;
        
        panel.add(label4, c);
        
        c.gridy = 1;
        c.gridx = 1;
        c.insets = new Insets(30, 5, 30,5); // default value  
        
        panel.add(label5, c);
        
        c.gridx = 2;
		c.insets = new Insets(30, 30, 30,30); // default value  
        
        panel.add(label6, c);


		c.gridy = 2;
        c.gridx = 0;
        c.insets = new Insets(0, 0, 50,0);
      
        button1.setPreferredSize(new Dimension(120, 40));
		panel.add(button1, c);
        
        c.gridx = 1;
        c.insets = new Insets(0, 68, 50,68);
        button2.setPreferredSize(new Dimension(120, 40));
		panel.add(button2, c);
		
        c.gridx = 2;
        c.insets = new Insets(0, 0, 50,0);

        button3.setPreferredSize(new Dimension(120, 40));
		panel.add(button3, c);
		
		panel3.setLayout(new GridBagLayout()); 
		
		JLabel bet = new JLabel("bet:$");
		panel3.setLayout(new GridBagLayout()); 
		b.insets = new Insets(10, 0, 70,0);
		panel3.add(bet,b);
		
        b.gridx = 1;
        b.insets = new Insets(10, 0, 70,0);

		panel3.add(field,b);
		
        b.gridx = 2;
        b.insets = new Insets(10, 10, 70,0);

		panel3.add(start,b);
		
		b.gridx = 3;
        b.insets = new Insets(10, 10, 70,0);

		panel3.add(result,b);
		
		b.gridx = 0;
		b.gridy = 1;
        b.insets = new Insets(0, 50, 50,0);
        b.weightx = 1.0;
		currentbet.setText("Please place your bet!");
		amount.setText("Amount of money you have:$" + wallet.getMoney());
		panel3.add(currentbet,b);
		
		b.gridx = 1;
        b.insets = new Insets(0, 80, 50,0);

		panel3.add(amount,b);
		
		start.addActionListener(new startListener());
		button1.addActionListener(new button1Listener());
		button2.addActionListener(new button2Listener());
		button3.addActionListener(new button3Listener());
		result.addActionListener(new resultListener());
		
	}

	// this metthod is to disable buttons for the beginning
	public void disable() {
		result.setEnabled(false);
		button1.setEnabled(false);
		button2.setEnabled(false);
		button3.setEnabled(false);
	}
	// this method is to write if the button start is clicked what action will be done, in this method 
	//it get string from text field, disable buttons, change the message boxes, and change the images of player's cards
	public class startListener implements ActionListener {  
		public void actionPerformed(ActionEvent event) {
			String a = field.getText();
			bet = Integer.parseInt(a);
			field.setText(""); 
			//System.out.println(bet);
			result.setEnabled(true);
			button1.setEnabled(true);
			button2.setEnabled(true);
			button3.setEnabled(true);
			//wallet.setmoney(bet);
			currentbet.setText("Your currentb bet is:$" + bet);
			amount.setText("Amount of money you have:$" + wallet.getMoney());
			start.setEnabled(false);
			cards card = new cards();
			card.Initializecards();
		    ImageIcon imageIcon = new ImageIcon("src//images//card_"+cards.top8cards.get(3)+".gif");
		    Image image1 = imageIcon.getImage().getScaledInstance(150, 230, Image.SCALE_SMOOTH);
			label4.setIcon(new ImageIcon(image1));
		    ImageIcon imageIcon2 = new ImageIcon("src//images//card_"+cards.top8cards.get(4)+".gif");
		    Image image2 = imageIcon2.getImage().getScaledInstance(150, 230, Image.SCALE_SMOOTH);
			label5.setIcon(new ImageIcon(image2));
		    ImageIcon imageIcon3 = new ImageIcon("src//images//card_"+cards.top8cards.get(5)+".gif");
		    Image image3 = imageIcon3.getImage().getScaledInstance(150, 230, Image.SCALE_SMOOTH);
			label6.setIcon(new ImageIcon(image3));
			calculator cal = new calculator();
			
			for (int i= 0; i<6;i++) {
				calculator.onhands.add(cards.top8cards.get(i));
			}
			
		}
	}
// this method is the action after relpace button is clicked, once clicked, the cards will be replace, the counted the replacement time		
	public class button1Listener implements ActionListener {  
		public void actionPerformed(ActionEvent event) {
			
		    ImageIcon imageIcon = new ImageIcon("src//images//card_"+cards.top8cards.get(6+replacecount)+".gif");
		    Image image1 = imageIcon.getImage().getScaledInstance(150, 230, Image.SCALE_SMOOTH);
			label4.setIcon(new ImageIcon(image1));
			
			if (replacecount==0) {
				button1.setEnabled(false);
				calculator.onhands.set(3, cards.top8cards.get(6));
			}
			else {
				button1.setEnabled(false);
				button2.setEnabled(false);
				button3.setEnabled(false);
				calculator.onhands.set(3, cards.top8cards.get(7));
			}
			replacecount++;
			
			

	}
}// this method is the action after relpace button is clicked, once clicked, the cards will be replace, the counted the replacement time	
	public class button2Listener implements ActionListener {  
		public void actionPerformed(ActionEvent event) {
			
		    ImageIcon imageIcon = new ImageIcon("src//images//card_"+cards.top8cards.get(6+replacecount)+".gif");
		    Image image1 = imageIcon.getImage().getScaledInstance(150, 230, Image.SCALE_SMOOTH);
			label5.setIcon(new ImageIcon(image1));
			
			if (replacecount==0) {
				button2.setEnabled(false);
				calculator.onhands.set(4, cards.top8cards.get(6));
			}
			else {
				button1.setEnabled(false);
				button2.setEnabled(false);
				button3.setEnabled(false);
				calculator.onhands.set(4, cards.top8cards.get(7));
			}
			replacecount++;
			
			

	}
}	
	// this method is the action after relpace button is clicked, once clicked, the cards will be replace, the counted the replacement time	
	public class button3Listener implements ActionListener {  
		public void actionPerformed(ActionEvent event) {
			
			
		    ImageIcon imageIcon = new ImageIcon("src//images//card_"+cards.top8cards.get(6+replacecount)+".gif");
		    Image image1 = imageIcon.getImage().getScaledInstance(150, 230, Image.SCALE_SMOOTH);
			label6.setIcon(new ImageIcon(image1));
			
			if (replacecount==0) {
				button3.setEnabled(false);
				calculator.onhands.set(5, cards.top8cards.get(6));
			}
			else {
				button1.setEnabled(false);
				button2.setEnabled(false);
				button3.setEnabled(false);
				calculator.onhands.set(5, cards.top8cards.get(7));
			}
			replacecount++;
			
			

	}
}	
	// this method is the action after result button is clicked, once clicked, the cards of dealer will be shown, and notice player the result by the message window,and set the money in wallet
	public class resultListener implements ActionListener {  
		public void actionPerformed(ActionEvent event) {
			
		    replacecount=0;
		    
		    ImageIcon imageIcon1 = new ImageIcon("src//images//card_"+cards.top8cards.get(0)+".gif");
		    Image image1 = imageIcon1.getImage().getScaledInstance(150, 230, Image.SCALE_SMOOTH);
			label.setIcon(new ImageIcon(image1));
			
		    ImageIcon imageIcon2 = new ImageIcon("src//images//card_"+cards.top8cards.get(1)+".gif");
		    Image image2 = imageIcon2.getImage().getScaledInstance(150, 230, Image.SCALE_SMOOTH);
			label2.setIcon(new ImageIcon(image2));
			
		    ImageIcon imageIcon3 = new ImageIcon("src//images//card_"+cards.top8cards.get(2)+".gif");
		    Image image3 = imageIcon3.getImage().getScaledInstance(150, 230, Image.SCALE_SMOOTH);
			label3.setIcon(new ImageIcon(image3));
			
			cards.top8cards.removeAll(cards.top8cards);

			for (int i= 0; i<6;i++) {
				//System.out.println("on hands " +  calculator.onhands.get(i));
			}
			
			calculator cal = new calculator();
			//System.out.println(cal.winorloss());
			
			customjdiabutton dia = new customjdiabutton();
			
			if (cal.winorloss()) {
				//System.out.println("ww" + wallet.getMoney());
				wallet.setmoney(-bet);
				dia.showDialogwin(frame);
				start.setEnabled(true);
				

			}
			else {
				wallet.setmoney(bet);
				if(wallet.getMoney()>0) {
					dia.showDialogloss(frame);
					start.setEnabled(true);
					//wallet.setmoney(bet);
				}
				
				if(wallet.getMoney()==0) {
					currentbet.setText("You have no more money! Please start a new game!");
					amount.setText("");
					dia.showDialogloss(frame);
					dia.showDialoglossall(frame);
					start.setEnabled(false);
				}
				
			}	
			
			
			
			
			
			
		    ImageIcon imageIcon4 = new ImageIcon("src//images//card_back.gif");
		    Image image4 = imageIcon4.getImage().getScaledInstance(150, 230, Image.SCALE_SMOOTH);
			calculator.onhands.removeAll(calculator.onhands);
			label.setIcon(new ImageIcon(image4));
			
		    //ImageIcon imageIcon5 = new ImageIcon("src//images//card_"+cards.top8cards.get(1)+".gif");
		    //Image image5 = imageIcon2.getImage().getScaledInstance(150, 230, Image.SCALE_SMOOTH);
			label2.setIcon(new ImageIcon(image4));
			
		    //ImageIcon imageIcon6 = new ImageIcon("src//images//card_"+cards.top8cards.get(2)+".gif");
		    //Image image6 = imageIcon3.getImage().getScaledInstance(150, 230, Image.SCALE_SMOOTH);
			label3.setIcon(new ImageIcon(image4));
			label4.setIcon(new ImageIcon(image4));
			label5.setIcon(new ImageIcon(image4));
			label6.setIcon(new ImageIcon(image4));
		    
			button1.setEnabled(false);
			button2.setEnabled(false);
			button3.setEnabled(false);
		    result.setEnabled(false);
		    bet = 0;
		    currentbet.setText("Please place your bet!");
			amount.setText("Amount of money you have:$" + wallet.getMoney());
			
		}

	}
	
			
				
			

}


	
		
	
	
	

