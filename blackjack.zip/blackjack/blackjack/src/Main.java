
public class Main {
/* * *******************************************************************************************************************************************************************************
 * to open this project properly, click "file" from menu bar, NEW> java project> unselect use default location, then broswe and select the wohle unzipped "Assignment3" folder***
 * 
 *   e.g C:\Users\ user\Downloads\Assignment3
 * *******************************************************************************************************************************************************************************
 */
	public static void main(String[] args) {
		GUI gui = new GUI();		// create gui
		gui.disable(); // disable button for starting
		gui.go(); // create panels
		

	}
	}
