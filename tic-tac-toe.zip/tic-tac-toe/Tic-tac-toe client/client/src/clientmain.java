import java.io.IOException;
import java.io.PrintWriter;
import java.net.*;

import javax.swing.SwingUtilities;

public class clientmain {
	public static void main(String[] args) throws UnknownHostException, IOException {
		GUI gui =  new GUI();
		gui.go();

	}

}







