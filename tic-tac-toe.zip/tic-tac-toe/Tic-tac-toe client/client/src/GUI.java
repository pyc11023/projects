import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

public class GUI extends JFrame implements ActionListener {
    private Socket sock;
    private PrintWriter writer;
    private BufferedReader reader;
    private JButton[][] buttons;
    private String xo = "X";
    private String message = "Enter your player name...";
    private JButton okButton = new JButton();
    private String longstring = "<html>Some information about the game:<br>"
            + "Criteria for a valid move:<br>"
            + "- The move is not occupied by any mark.<br>"
            + "- The move is made in the player's turn.<br>"
            + "- The move is made within the 3 × 3 board.<br>"
            + "The game would continue and switch among the opposite player until it reaches either one of the following conditions:<br>"
            + "- Player 1 wins.<br>"
            + "- Player 2 wins.<br>"
            + "- Draw.</html>";

    JTextField field = new JTextField();
    JLabel msg = new JLabel(message);
    JLabel ins = new JLabel(longstring);
    JButton submit = new JButton("submit");
    String name;
    int seqofmove = 0;
    boolean myTurn = false;
    String opp = "O";
    String[][] board = {
            {"", "", ""},
            {"", "", ""},
            {"", "", ""}
    };
    int opponentSeq = 0;

    public GUI() {
    }

    public void go() {
        setTitle("Tic Tac Toe");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Menu setup
        JMenuBar menuBar = new JMenuBar();
        JMenu menu = new JMenu("Control");
        JMenu menu2 = new JMenu("Help");
        JMenuItem menuItem2 = new JMenuItem("Instruction");
        JMenuItem menuItem = new JMenuItem("Exit");
        menuItem.addActionListener(e -> System.exit(0));
        menu.add(menuItem);
        menuBar.add(menu);
        menu2.add(menuItem2);
        menuBar.add(menu2);
        setJMenuBar(menuBar);

        menuItem2.addActionListener(e -> {
            JDialog instructionDialog = new JDialog(GUI.this, "Instructions", true);
            instructionDialog.setLayout(new BorderLayout());
            instructionDialog.add(ins);
            okButton.setText("OK");
            okButton.addActionListener(ev -> instructionDialog.dispose());
            instructionDialog.add(okButton, BorderLayout.SOUTH);
            instructionDialog.setSize(650, 400);
            instructionDialog.setLocationRelativeTo(GUI.this);
            instructionDialog.setVisible(true);
        });

        // Layout setup
        setLayout(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();

        JPanel panel0 = new JPanel();
        JPanel panel1 = new JPanel();
        JPanel panel2 = new JPanel();

        panel0.add(msg);
        c.anchor = GridBagConstraints.WEST;
        c.gridy = 0;
        c.gridx = 0;
        add(panel0, c);

        panel1.setLayout(new GridLayout(3, 3));
        buttons = new JButton[3][3];
        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < 3; col++) {
                buttons[row][col] = new JButton();
                buttons[row][col].setPreferredSize(new Dimension(100, 100));
                buttons[row][col].setFont(new Font("Arial", Font.BOLD, 80));
                buttons[row][col].addActionListener(this);
                panel1.add(buttons[row][col]);
                buttons[row][col].setEnabled(false);
            }
        }
        c.anchor = GridBagConstraints.CENTER;
        c.gridy = 1;
        c.gridx = 0;
        add(panel1, c);

        setSize(350, 450);
        c.gridy = 2;
        c.gridx = 0;
        field.setPreferredSize(new Dimension(200, 30));
        panel2.add(field);
        submit.setPreferredSize(new Dimension(80, 30));
        panel2.add(submit);
        submit.addActionListener(new SubmitListener());
        add(panel2, c);

        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (!myTurn) return; // Only allow moves on player's turn

        JButton clickedButton = (JButton) e.getSource();
        if (!clickedButton.getText().isEmpty()) return; // Prevent overwriting

        clickedButton.setText(xo);
        int a = 0, b = 0;
        for (int r = 0; r < 3; r++) {
            for (int c = 0; c < 3; c++) {
                if (clickedButton == buttons[r][c]) {
                    System.out.println("Button clicked at row " + r + ", column " + c);
                    board[r][c] = xo;
                    a = r;
                    b = c;
                }
            }
        }

        try {
            writer.println("moved" + seqofmove + " " + a + " " + b);
            System.out.println("Sent: moved" + seqofmove + " " + a + " " + b);
            message = "Valid move, wait for your opponent";
            msg.setText(message);
            myTurn = false;
            disableButtons();

            // Check if this move wins
            String winner = checkWinner();
            if (winner != null) {
                handleGameEnd(winner);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    private void listenToServer() {
        try {
            String read;
            while ((read = reader.readLine()) != null) {
                System.out.println("Received: " + read);
                String[] parts = read.split(" ");

                if (parts.length >= 3 && parts[0].equals("moved" + opponentSeq)) {
                    int oppRow = Integer.parseInt(parts[1]);
                    int oppCol = Integer.parseInt(parts[2]);
                    board[oppRow][oppCol] = opp;
                    buttons[oppRow][oppCol].setText(opp);
                    message = "Your opponent has moved, now is your turn";
                    msg.setText(message);
                    myTurn = true;
                    enableButtons();

                    // Check if opponent's move wins
                    String winner = checkWinner();
                    if (winner != null) {
                        handleGameEnd(winner);
                    }
                } else if (read.equals("Opponent disconnected")) {
                    message = "Opponent disconnected. Game over.";
                    msg.setText(message);
                    disableButtons();
                    break;
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
            message = "Connection lost";
            msg.setText(message);
            disableButtons();
        }
    }

    private void disableButtons() {
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                buttons[i][j].setEnabled(false);
            }
        }
    }

    private void enableButtons() {
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                if (board[i][j].isEmpty()) {
                    buttons[i][j].setEnabled(true);
                }
            }
        }
    }

    // New method to check for a winner
    private String checkWinner() {
        // Check rows
        for (int i = 0; i < 3; i++) {
            if (!board[i][0].isEmpty() && board[i][0].equals(board[i][1]) && board[i][1].equals(board[i][2])) {
                return board[i][0]; // "X" or "O"
            }
        }

        // Check columns
        for (int i = 0; i < 3; i++) {
            if (!board[0][i].isEmpty() && board[0][i].equals(board[1][i]) && board[1][i].equals(board[2][i])) {
                return board[0][i];
            }
        }

        // Check diagonals
        if (!board[0][0].isEmpty() && board[0][0].equals(board[1][1]) && board[1][1].equals(board[2][2])) {
            return board[0][0];
        }
        if (!board[0][2].isEmpty() && board[0][2].equals(board[1][1]) && board[1][1].equals(board[2][0])) {
            return board[0][2];
        }

        // Check for draw
        boolean boardFull = true;
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                if (board[i][j].isEmpty()) {
                    boardFull = false;
                    break;
                }
            }
            if (!boardFull) break;
        }
        if (boardFull) {
            return "draw";
        }

        return null; // No winner yet
    }

    // Handle game end conditions
    private void handleGameEnd(String winner) {
        if (winner.equals("draw")) {
            message = "Game ended in a draw!";
        } else if (winner.equals(xo)) {
            message = "You win!";
        } else {
            message = "Your opponent wins!";
        }
        msg.setText(message);
        disableButtons();
    }

    public class SubmitListener implements ActionListener {
        public void actionPerformed(ActionEvent event) {
            try {
                sock = new Socket("127.0.0.1", 5000);
                writer = new PrintWriter(sock.getOutputStream(), true);
                reader = new BufferedReader(new InputStreamReader(sock.getInputStream()));

                writer.println("connect");
                System.out.println("connect");

                String result = reader.readLine();
                System.out.println("result: " + result);

                if (result == null) {
                    message = "Error: No response from server";
                    msg.setText(message);
                    return;
                }

                submit.setEnabled(false);
                name = field.getText();
                message = "WELCOME " + name;
                msg.setText(message);

                if (result.equals("1")) {
                    myTurn = true;
                    seqofmove = 1;
                    opponentSeq = 2;
                    xo = "X";
                    opp = "O";
                    message = "Connected as Player 1, your turn";
                    msg.setText(message);
                    enableButtons();
                } else if (result.equals("2")) {
                    myTurn = false;
                    seqofmove = 2;
                    opponentSeq = 1;
                    xo = "O";
                    opp = "X";
                    message = "Connected as Player 2, waiting for Player 1";
                    msg.setText(message);
                    disableButtons();
                }

                // Start the listener thread AFTER connection is established
                new Thread(GUI.this::listenToServer).start();

            } catch (Exception ex) {
                ex.printStackTrace();
                message = "Error: Connection failed";
                msg.setText(message);
            }
        }
    }
}