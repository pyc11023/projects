import java.io.*;
import java.net.*;
import java.util.ArrayList;

public class servermain {
    private ArrayList<ClientHandler> clients = new ArrayList<>();
    private command cmd = new command();

    public static void main(String[] args) {
        servermain server = new servermain();
        server.go();
    }

    public void go() {
        System.out.println("Server started");
        try (ServerSocket serverSock = new ServerSocket(5000)) {
            while (true) {
                Socket sock = serverSock.accept();
                System.out.println("New client connected: " + sock.getInetAddress());
                ClientHandler client = new ClientHandler(sock);
                clients.add(client);
                new Thread(client).start();
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    class ClientHandler implements Runnable {
        private Socket sock;
        private PrintWriter writer;
        private BufferedReader reader;

        public ClientHandler(Socket socket) {
            this.sock = socket;
            try {
                writer = new PrintWriter(sock.getOutputStream(), true);
                reader = new BufferedReader(new InputStreamReader(sock.getInputStream()));
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        @Override
        public void run() {
            try {
                String request;
                while ((request = reader.readLine()) != null) {
                    System.out.println("Request: " + request);
                    String response = cmd.distinguish(request, sock);
                    writer.println(response);

                    // Broadcast move to other player
                    if (request.startsWith("moved")) {
                        for (ClientHandler client : clients) {
                            if (client != this) {  // Skip the sender
                                client.writer.println(request);
                            }
                        }
                    }
                }
            } catch (IOException e) {
                System.out.println("Client disconnected: " + sock.getInetAddress());
            } finally {
                try {
                    reader.close();
                    writer.close();
                    sock.close();
                    clients.remove(this);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}