import java.io.*;
import java.net.Socket;

public class command {
    int[] players = new int[2];
    int count = 0;
    String currentmoving = "1";
    String[][] board = {
        {"", "", ""},
        {"", "", ""},
        {"", "", ""}
    };

    public String distinguish(String cmd1, Socket sock) throws IOException {
        String[] parts = cmd1.split(" ");
        if (cmd1.equals("connect")) {
            return startornot(sock);
        }
        if (cmd1.equals("update")) {
            System.out.println("updated");
            return currentmoving;
        }
        if (parts[0].equals("moved1")) {
            board[Integer.parseInt(parts[1])][Integer.parseInt(parts[2])] = "X";
            //printBoard();
            currentmoving = "2";
            System.out.println("currentmoving= 2");
            String winner = checkWinner();
            if (winner != null) {
                return "winner " + winner;
            }
            return "moved1 " + parts[1] + " " + parts[2];
        }
        if (parts[0].equals("moved2")) {
            board[Integer.parseInt(parts[1])][Integer.parseInt(parts[2])] = "O";
            //printBoard();
            currentmoving = "1";
            System.out.println("currentmoving= 1");
            String winner = checkWinner();
            if (winner != null) {
                return "winner " + winner;
            }
            return "moved2 " + parts[1] + " " + parts[2];
        }
        return cmd1;
    }

    private String startornot(Socket sock) throws IOException {
        if (count == 0) {
            System.out.println("1");
            count++;
            return "1";
        } else if (count == 1) {
            System.out.println("2");
            count++;
            return "2";
        }
        return "0"; // Game full
    }

    private String update() {
        return currentmoving;
    }

    // New method to check for a winner
    public String checkWinner() {
        // Check rows
        for (int i = 0; i < 3; i++) {
            if (!board[i][0].isEmpty() && board[i][0].equals(board[i][1]) && board[i][1].equals(board[i][2])) {
                return board[i][0]; // Returns "X" or "O"
            }
        }

        // Check columns
        for (int i = 0; i < 3; i++) {
            if (!board[0][i].isEmpty() && board[0][i].equals(board[1][i]) && board[1][i].equals(board[2][i])) {
                return board[0][i];
            }
        }

        // Check diagonals
        if (!board[0][0].isEmpty() && board[0][0].equals(board[1][1]) && board[1][1].equals(board[2][2])) {
            return board[0][0];
        }
        if (!board[0][2].isEmpty() && board[0][2].equals(board[1][1]) && board[1][1].equals(board[2][0])) {
            return board[0][2];
        }

        // Check for draw (board full, no winner)
        boolean boardFull = true;
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                if (board[i][j].isEmpty()) {
                    boardFull = false;
                    break;
                }
            }
            if (!boardFull) break;
        }
        if (boardFull) {
            return "draw";
        }

        // No winner yet
        return null;
    }
}