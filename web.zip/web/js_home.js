function showTime() {
    const now = new Date();
    const YY = now.getFullYear();
    const MM = now.getMonth();
    const DD = now.getDate();
    const hours = now.getHours();
    const minutes = now.getMinutes();
    const seconds = now.getSeconds();
    const YMDString = `${YY}-${MM}-${DD}`;
    const timeString = `${hours}:${minutes}:${seconds}`;

    document.getElementById("clock").textContent = timeString;
    document.getElementById("cal").textContent = YMDString;
}

// Call showTime function immediately to display the time
showTime();

// Update the clock every second
setInterval(showTime, 1000);