document.addEventListener('DOMContentLoaded', function() {
  document.querySelectorAll('.skills-prog ul li').forEach(item => {
    const percent = item.getAttribute('data-percent');
    const bar = item.querySelector('.skills-bar .bar');
    bar.style.setProperty('--percent-width', `${percent}%`);
  });
});
  
